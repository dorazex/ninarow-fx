public class GameBasic extends Game {
}
